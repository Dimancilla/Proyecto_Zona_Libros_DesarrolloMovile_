package com.example.zona_libros.models

data class LoginModel (
    val email: String,
    val password: String
)


