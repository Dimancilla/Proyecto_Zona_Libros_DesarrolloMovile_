package com.example.zona_libros.models

class LoginModel {
}