package com.example.zona_libros.models

data class Libro (
    val id: Int,
    val titulo: String,
    val autor: String,
    val genero: String
)